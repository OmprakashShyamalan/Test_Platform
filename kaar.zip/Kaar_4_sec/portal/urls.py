from django.conf.urls import include, url
from django.contrib import admin
from . import views
from django.conf.urls import handler404, handler500
urlpatterns = [
      url(r'^$', views.index , name='index'),
      url(r'^index$', views.index , name='index'),
      url(r'^instructions$', views.instructions , name='instructions'),
      url(r'^student$', views.student , name='student'),
      url(r'^signin$', views.signin , name='signin'),
      url(r'^test$', views.test , name='test'),
      url(r'^endtest$', views.finish , name='endtest'),
      url(r'^check$', views.check , name='check'),
]

# handler404 = views.error_500
# handler500 = views.error_500